package com.example.mappings.hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
